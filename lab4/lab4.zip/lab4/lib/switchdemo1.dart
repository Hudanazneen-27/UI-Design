class switchdemo1 {
String switchfr(String f){
	return switch (f){
	 'apple' || 'Apple' => f,
		
		
	'pineapple' || 'Pineapple' => f,
		
        'orange' || 'Orange' => f,

	_ =>" not list",		
		
	};
	
 	

}	
	
}
