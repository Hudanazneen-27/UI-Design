class switch1 {
void switchb(String f){
	var x = switch (f){
	 'apple' || 'Apple' => f,
		
		
	'pineapple' || 'Pineapple' => f,
		
        'orange' || 'Orange' => f,

	_ =>" not list",		
		
	};
 	print(x);

}	
	
}
