class cases {
void cdemo(String name){
	switch (name){
	case 'apple' || 'Apple' || 'APPLE'|| 'aPPle':
		print("It is a fruit");
		
	case 'pineapple' || 'Pineapple' || 'PINEAPPLE' || 'PineApple':
		print("It is a fruit");
		
	case 'orange' || 'Orange' || 'ORANGE' || 'OrangE':
		print("It is a fruit");
		
	default:
		print ("Sorry, It is not in list");
		
		}
	}
}
