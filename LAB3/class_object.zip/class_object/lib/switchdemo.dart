
class switchdemo {
void sdemo(String name){
	switch (name){
	case 'apple' || 'Apple':
		print("It is a fruit");
		
	case 'pineapple' || 'Pineapple':
		print("It is a fruit");
		
	case 'orange' || 'Orange':
		print("It is a fruit");
		
	default:
		print ("Sorry, It is not in list");
		
		}
	}
}
